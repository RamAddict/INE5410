package br.ufsc.atividade11;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Market {
    private final Map<Product, Double> prices = new HashMap<>();
    private final Map<Product, ReentrantReadWriteLock> locks = new HashMap<>();
    private final Map<Product, Condition> conditions = new HashMap<>();
    
    public Market() {
        for (Product product : Product.values()) {
            prices.put(product, 1.99);
            ReentrantReadWriteLock rwlock = new ReentrantReadWriteLock();
            locks.put(product, rwlock);
            conditions.put(product, rwlock.writeLock().newCondition());
        }
    }

    public void setPrice(@Nonnull Product product, double value) {
        
        (locks.get(product)).writeLock().lock();
        try {
            if (prices.get(product) > value) {
                conditions.get(product).signalAll();
            }
            prices.put(product, value);
        } finally {
            (locks.get(product)).writeLock().unlock();
        }
    }

    public double take(@Nonnull Product product) {
        locks.get(product).readLock().lock();
        return prices.get(product);
    }

    public void putBack(@Nonnull Product product) {
        locks.get(product).readLock().unlock();
    }

    public double waitForOffer(@Nonnull Product product,
                               double maximumValue) throws InterruptedException {
        locks.get(product).writeLock().lock();
        try {
            //deveria esperar até que prices.get(product) <= maximumValue
            while (!(prices.get(product) <= maximumValue)) {
                conditions.get(product).await();
            }
            take(product);
            return prices.get(product);
        } finally {
            locks.get(product).writeLock().unlock();
        }
    }

    public double pay(@Nonnull Product product) {
        Product mine = product;
        try {
            return prices.get(mine);
        } finally {
            locks.get(mine).readLock().unlock();
        }
    }
}
