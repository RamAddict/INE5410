package br.ufsc.atividade11;

public enum Product {
    NOODLES,
    BREAD,
    CHEESE,
    COOKIES,
    TOMATO_SAUCE,
    PIZZA,
    LASAGNA,
    COKE,
    COFFEE,
}
